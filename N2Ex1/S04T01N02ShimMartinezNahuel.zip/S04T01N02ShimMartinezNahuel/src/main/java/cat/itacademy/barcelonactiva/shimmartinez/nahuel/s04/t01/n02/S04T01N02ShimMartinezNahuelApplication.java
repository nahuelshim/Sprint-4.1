package cat.itacademy.barcelonactiva.shimmartinez.nahuel.s04.t01.n02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N02ShimMartinezNahuelApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N02ShimMartinezNahuelApplication.class, args);
	}

}
