package cat.itacademy.barcelonactiva.shimmartinez.nahuel.s04.t01.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N01ShimMartinezNahuelApplicationTests {

	@Test
	void contextLoads() {
	}

}
